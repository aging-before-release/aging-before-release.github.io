"""agingbench (telemetry-only subset for browser demo)"""
__version__ = "0.3.0-browser"
